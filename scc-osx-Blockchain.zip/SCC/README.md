# Blockchain SCC
# version 1.3.2

# Copyright © 2025 by KhoaPython-dev

# a project creator by Dot Team & KhoaPython-dev


# use: 

# 1. start package

# frist, run the command: 
# cd frist:
"cd SCC"
# continue:
"pip install -r requirements.txt"

# 2. run server
# note: please cd to "main-dir (is ~)" and run command

"python3 SCC/core/blockchain/main.py"

# active server blockchain 

# run blockchain request:
# 100 MB- 2GB ROM (internal storage) 
# 1 GB RAM

# don't touch on data/index/0 because it is data all block!


