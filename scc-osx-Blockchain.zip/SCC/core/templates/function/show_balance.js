const fs = require("fs")

const IDUser = fs.readFileSync("SCC/core/templates/function/name.txt", "utf8").trim()
const token = fs.readFileSync(`SCC/core/data/token/walletID_${IDUser}.scc`, "utf8")

let table = {
	"username": IDUser,
	"token": token,
	"price": Number(token) * 0.0008292384
        }

console.table([table])

