import time
import json
import hashlib
import os
import socket

HOST = "127.0.0.1"
PORT = 25114


def ensure_dir(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)


def method_get(name, method, text=None):
    path = f"SCC/core/data/token/walletID_{name}.scc"
    ensure_dir(path)

    if method == "write":
        with open(path, "w") as f:
            f.write(str(text))
    elif method == "read":
        if not os.path.exists(path):
            return "0"
        with open(path, "r") as f:
            return f.read().strip()
    return None


def send_to_blockchain(transaction: dict):
    """Đẩy transaction sang blockchain node qua socket"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((HOST, PORT))
            s.sendall(json.dumps(transaction).encode())
            res = s.recv(4096).decode(errors="ignore")
            print("[BLOCKCHAIN RESPONSE]", res)
    except Exception as e:
        print("[ERROR SEND BLOCKCHAIN]", e)


def wallet_transaction(sender: str, target: str, amount: float):
    """Thực hiện chuyển token giữa 2 ví, và gửi transaction sang blockchain"""
    print("wait a minute...")

    # đọc số dư
    token_sender = float(method_get(name=sender, method="read") or 0.0)
    if token_sender < amount:
        raise ValueError("Not enough token to send!")

    # cập nhật số dư người gửi
    total_sender = token_sender - amount
    method_get(name=sender, method="write", text=total_sender)

    # cập nhật số dư người nhận
    token_claimer = float(method_get(name=target, method="read") or 0.0)
    total_claimer = token_claimer + amount
    method_get(name=target, method="write", text=total_claimer)

    # tạo transaction object
    tx = {
        "from": sender,
        "to": target,
        "amount": amount,
        "type": "send",
        "timestamp": time.time(),
    }

    # gửi transaction sang blockchain để ghi block
    send_to_blockchain(tx)

    return {
        "sender_balance": total_sender,
        "receiver_balance": total_claimer,
        "transaction": tx,
    }

def main():
  sender = input("enter your name: ")
  claimer = input("enter your name claim: ")
  token = input("enter your token want send: ")
  os.system("python3 SCC/core/blockchain/osx.py")
  wallet_transaction(sender, claimer, token)

main()