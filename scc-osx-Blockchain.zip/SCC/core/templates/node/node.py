import socket
import sys
import time
from colorama import Fore
import random

HOST = "127.0.0.1"   
PORT = 25308         
TOKEN_PRICE = 0.0008292384


def mine(miner_name):
  with open("SCC/core/data/cache/name.txt", "w") as f:
    f.write(miner_name)
    while True:
        try:
          
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))

                
                data = f"@node-miner: {miner_name} // {time.time()}"
                s.sendall(data.encode())

                
                res = s.recv(1024).decode(errors="ignore")

                
                reward = 0.0
                if "[TOKEN]:" in res:
                    try:
                        reward_str = res.split("[TOKEN]:")[1].split("(")[0].strip()
                        reward = float(reward_str)
                    except:
                        reward = 0.0

                print(
                    f"{Fore.GREEN}[SCC] NAME:{miner_name} []REWARD={reward:.6f} "
                    f"{Fore.BLUE}({reward * TOKEN_PRICE:.6f}) //STATUS=pass"
                )

            
            

        except Exception as e:
            print("[ERROR]", e)
            time.sleep(5)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python3 node.py <MinerName>")
        sys.exit(1)

    miner = sys.argv[1]
    mine(miner)

