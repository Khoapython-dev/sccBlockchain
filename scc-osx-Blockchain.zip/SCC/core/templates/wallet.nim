import os, strutils, times

var username = "guest"

proc clearScreen() =
  if hostOS == "windows":
    discard execShellCmd("cls")
  else:
    discard execShellCmd("clear")

proc balance() =
  let total = "SCC/core/templates/function/show_balance.js"
  clearScreen()
  discard execShellCmd("node " & total)

proc loginOrResigner(): bool =
  global username
  clearScreen()
  stdout.write("Enter Username: ")
  username = stdin.readLine().strip()
  let total = "SCC/core/data/token/walletID_" & username & ".scc"
  if fileExists(total):
    echo "welcome ", username, " to SCC Wallet!"
    sleep(2000)  # 2s
  else:
    echo "Wrong username or username not exists!"
    return false
  return true

proc main() =
  clearScreen()
  echo "=== SCC-WALLET ==="   # nim chicken vcl

  if not loginOrResigner():
    return

  while true:
    echo ""
    echo "=============== ", username, " ==============="
    echo "=== choose:"
    echo "== 1. show balance"
    echo "== 2. version"
    echo "== 3. send token"
    echo "== 'exit', 'bye', 'out' to exit"
    echo "=========================================="
    stdout.write("choose: ")
    let intp = stdin.readLine()
    case intp
    of "1":
      balance()
    of "2":
      clearScreen()
      echo "1.1.0 | Core: SCC Blockchain | mining: None"
    of "3":
      discard execShellCmd("python3 SCC/core/templates/function/transaction.py")
    of "exit", "quit", "out", "bye":
      clearScreen()
      break
    else:
      clearScreen()
      echo "wrong choose, try again"

when isMainModule:
  main()