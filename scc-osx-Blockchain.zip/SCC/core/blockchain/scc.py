import os
import json
import hashlib
import time
import random
from colorama import Fore
import asyncio

# byte can claim up to 1MB (1000kB)
max_byte = 1000000
total_reward = 0

# difficulty ban đầu
difficulty = 4
previous_hash = "0"  # genesis block



def plus_wallet(plus_token):
  with open("SCC/core/data/cache/name.txt", "r") as f:
    miner = f.read()
    path = f"SCC/core/data/token/walletID_{miner}.scc"
    try:
        with open(path, "r") as f:
            total = float(f.read())
        sumcoin = total + plus_token
        with open(path, "w") as f:
            f.write(str(sumcoin))
    except:
        with open(path, "w") as f:
            f.write(str(plus_token))

def sum_reward_block():
  choice = ["0x018TPE", "0x019NSL", "0x032QKD", "0x083NXL", "0x99PPT"]
  random_hex = random.choice(choice)
  if random_hex == "0x018TPE":
    TPE = random.uniform(0.00382, 0.01826) * 2 
    return TPE
  elif random_hex == "0x019NSL":
    NSL = random.uniform(0.04928, 0.82926) * 2.4 
    return NSL 
  elif random_hex == "0x032QKD":
    QKD = random.uniform(0.9827, 1.594) * 2.8 
    return QKD
  elif random_hex == "0x083NXL":
    NXL = random.uniform(1.8372, 3.19182) * 2.85 
    return NXL 
  elif random_hex == "0x99PPT":
    PPT = random.uniform(8.2018, 32.18272) * 2.99 
    return PPT 
  
def genesis_block(data):
    global previous_hash, difficulty, total_reward, limited_block

    folder = "SCC/core/data/index/0"
    os.makedirs(folder, exist_ok=True)

    existing_files = os.listdir(folder)
    index = len(existing_files)

    timestamp = time.time()
    transactions = [data] if data else []

    block = {
        "index": index,
        "timestamp": timestamp,
        "previous_hash": previous_hash,
        "transactions": transactions,
    }

    nonce = 0
    prefix = "0" * difficulty
    while True:
        block_str = json.dumps({**block, "nonce": nonce})
        hash_try = hashlib.sha256(block_str.encode()).hexdigest()
        if hash_try.startswith(prefix):
            block["nonce"] = nonce
            block["hash"] = hash_try
            break
        nonce += 1

    previous_hash = block["hash"]

    with open(f"{folder}/block-{index}.fmc", "w") as f:
        f.write(json.dumps(block, indent=4))
        
    print(f"{Fore.GREEN}[BLOCK CREATED] block: {index}|{Fore.BLUE} hash: {block['hash']}")

    reward = sum_reward_block()
    total_reward += reward
    block["reward"] = f"token={reward}"
    return reward


async def handle_client(reader, writer):
    addr = writer.get_extra_info("peername")
    print(f"{Fore.BLUE}[CONNECT] Connected from:", addr)

    try:
        while True:
            data = await reader.read(max_byte)
            if not data:
                break

            msg = data.decode().strip()
            reward = genesis_block(msg)
            plus_wallet(reward)

            response = f"{Fore.GREEN}[SCC] mined! //[TOKEN]: {reward} ({reward * 0.008292384}$) //[STATUS]: pass"
            writer.write(response.encode())
            await writer.drain()
    except Exception as e:
        print("[ERROR]", e)
    finally:
        writer.close()
        await writer.wait_closed()
        print("[DISCONNECT]", addr)


async def main():
    server = await asyncio.start_server(
        handle_client, "0.0.0.0", 25308
    )
    addr = server.sockets[0].getsockname()
    print(f"[SCC] Start Blockchain Server on: {addr}")

    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[SCC] Shutting down...")

