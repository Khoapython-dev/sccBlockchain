import socket


soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.bind(("0.0.0.0", 25114))
soc.listen(5)  

count = 0

while True:
    conn, addr = soc.accept()
    print("[OSX] Connect: ", addr)

    while True:
        
        count += 1
        ic = str(count)
        data = conn.recv(1000000)  
        if not data:  
             break
        with open("SCC/core/data/index/transaction/txBlock-{ic}.scc", "w") as f:
          f.write(data.decode())
        conn.sendall(b"Writed!")  

    conn.close()
